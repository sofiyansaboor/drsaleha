<!DOCTYPE html>
<html>
    <head>
        <title>Shangri La — FLORENT PETITFRERE</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="Content-Language" content="fr">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scale=no">

        <meta name="Description" content="Here the idleness of large cities has no hold, work is an integral part of everyday life, mutual aid takes precedence over individualism.">
        <meta name="Keywords" content="">
        <meta name="Author" content="LE GRAPHOIR X PAACK">
        <meta name="Robots" content="all">
        <meta name="Rating" content="general">
        <meta name="Distribution" content="global">
        <meta name="Geography" content="Montpellier">

        <link rel="icon" type="image/png" href="/fp_favicon.png" />
        <link rel="apple-touch-icon" href="/fp_apple-icon.png">

        <link rel="stylesheet" href="/css/style.css">
<link rel="stylesheet" href="/css/slider.css">
<link rel="stylesheet" href="/fonts/fonts.css">

<link rel="stylesheet" type="text/css" href="/css/slick.css">
<link rel="stylesheet" type="text/css" href="/css/slick-theme.css">

        <meta property="og:title" content="Shangri La — FLORENT PETITFRERE" />
        <meta property="og:description" content="Here the idleness of large cities has no hold, work is an integral part of everyday life, mutual aid takes precedence over individualism." />
        <meta property="og:url" content="" />
        <meta property="og:type" content="website">
        <meta property="og:image" content="" />
    </head>

    <body class="galerie documentary">
        <div class="conteneur">
            <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-100121742-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Hotjar Tracking Code for http://florentpetitfrere.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:537502,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<header class="">
    <div class="header-top">
        <div class="logo desktop">
            <a class="next-page" data-href="/index.php">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="272.5px" height="766.3px" viewBox="0 0 272.5 766.3" style="enable-background:new 0 0 272.5 766.3;" xml:space="preserve">
                    <defs>
                    </defs>
                    <g>
                        <path d="M0,670.2h32.6v2.9c-31.2,6-29.6,52.4-29.6,52.4v6h55.2v-6c0,0,0.7-26.4-17.6-29.5v-2.9H79v2.9
                            c-18.3,3.1-17.6,29.5-17.6,29.5v6h35.8c19.4,0,20.6-7.4,20.6-14.7h2.9v49.5h-2.9c0-7.4-8.9-9.9-20.6-9.9H23.6
                            c-10.6,0-20.7,2.4-20.7,9.9H0V670.2z"/>
                        <path d="M117.7,626.7h2.9v35.1h-2.9c-1.9-6.5-9.1-6.9-17.8-6.9H24.7c-6,0-8.6,1.7-11.1,8.6h-4l-3.9-30h94.2
                            C109.3,633.6,116.2,632.7,117.7,626.7z"/>
                        <path d="M81,533.5c22.4,0,41.1,14.6,41.1,40.8c0,26-18.7,40.8-41.1,40.8c-22.6,0-41.1-14.7-41.1-40.8
                            C39.9,548.1,58.4,533.5,81,533.5z M81,558.9c-31,0-38.2,3.1-38.2,15.4S50,589.9,81,589.9c31,0,38.2-3.3,38.2-15.6
                            S112,558.9,81,558.9z"/>
                        <path d="M43,460.2c4.6-5.3,12.8-5.8,18-1.2c5.3,4.6,6,12.5,1.4,18c-2.4,2.6-5.3,3.9-8.4,3.9c-1.9,0-0.2,7,10.1,13.4h35.6
                            c9.6,0,16.3-0.9,18-7h2.9v35.5h-2.9c-2.1-6.7-9.1-6.9-18-6.9h-38c-5.8,0-8.4,1.5-12,8.6h-4.5l-3.9-30.2h18
                            c-14.2-9.1-16.8-16.1-18.5-20.2C39.2,470.4,39.9,463.9,43,460.2z"/>
                        <path d="M79.5,371.2v54.5c16.8-1.4,25.5-9.9,28.1-21.4c2.1-9.3-1.4-23-9.4-27.2l1.5-2.9c8.9,2.7,22.4,12.8,22.4,35.8
                            c0,22.4-20.7,37.9-40.8,37.9c-24.2,0-41.5-16.4-41.5-40.1C39.9,382.9,52.8,371.2,79.5,371.2z M76.6,392.1c-21.6,0-33.7,7-33.7,16.4
                            c0,10.1,17.3,17.1,33.7,17.1V392.1z"/>
                        <path d="M117.7,275.6h2.9v35.3h-2.9c-1.9-6.5-9.2-6.9-18-6.9H66.5c-8.2,0-14.2,5.3-14.2,13.9c0,6.7,7.2,14.6,14.1,14.6h33.7
                            c9.4,0,15.9-1,17.6-7h2.9v35.1h-2.9c-1.9-6.5-8.9-6.7-17.6-6.7H61.3c-6,0-7.9,1.5-11.7,8.6h-4.2l-3.9-30h16.7
                            c-10.4-3.9-18.3-17.5-18.3-28.3c0-13.4,5.3-21.6,26-21.6h33.7C109.1,282.6,116.2,281.8,117.7,275.6z"/>
                        <path d="M104,215.5l1.5-2.6c8.1,3.4,16.6,13.9,16.6,25.4c0,13.5-5.5,21.6-26.2,21.6H44.4v8.6l-2.9,0.5v-9.1H11l-2.8-21.4h33.2V218
                            l2.9,0.7v19.7h51.1c9.6,0,14.6-4.1,14.6-12.7C110,220.8,106.6,217,104,215.5z"/>
                        <path d="M219.6,729.2h27.9c19.4,0,20.6-12.9,20.6-20.2h2.9v56.4h-2.9c0-7.2-8.9-11.3-20.6-11.3H173c-10.6,0-19.7,4.8-19.7,12.3
                            h-2.9V723c0-34.1,6-58.3,34.6-58.3c28.6,0,34.6,24.2,34.6,58.3V729.2z M216.7,729.2V723c0-16.8-1.4-30.2-31.7-30.2
                            c-30.5,0-31.7,13.4-31.7,30.2v6.2H216.7z"/>
                        <path d="M229.9,584.3v54.5c16.8-1.4,25.5-9.9,28.1-21.4c2.1-9.2-1.4-23-9.4-27.2l1.5-2.9c8.9,2.7,22.4,12.8,22.4,35.8
                            c0,22.4-20.7,37.9-40.8,37.9c-24.2,0-41.5-16.4-41.5-40.1C190.3,595.9,203.1,584.3,229.9,584.3z M227,605.2
                            c-21.6,0-33.7,7-33.7,16.4c0,10.1,17.3,17.1,33.7,17.1V605.2z"/>
                        <path d="M254.4,520.9l1.5-2.6c8.1,3.4,16.6,13.9,16.6,25.4c0,13.5-5.5,21.6-26.2,21.6h-51.6v8.6l-2.9,0.5v-9.1h-22.6l-2.8-21.4
                            h25.4v-20.4l2.9,0.7v19.7h51.1c9.6,0,14.6-4.1,14.6-12.7C260.4,526.2,256.9,522.4,254.4,520.9z"/>
                        <path d="M268.1,474.8h2.9v35.1h-2.9c-2.1-6.5-9.2-6.9-18-6.9h-38c-5.8,0-8.2,1.7-12,8.7h-3.6l-3.9-30h57.6
                            C259.7,481.8,266.4,480.9,268.1,474.8z M183.2,494.1c0,6.5-5.1,11.7-11.6,11.7s-11.6-5.1-11.6-11.7c0-6.5,5.1-11.8,11.6-11.8
                            S183.2,487.6,183.2,494.1z"/>
                        <path d="M254.4,411.9l1.5-2.6c8.1,3.4,16.6,13.9,16.6,25.4c0,13.5-5.5,21.6-26.2,21.6h-51.6v8.6l-2.9,0.5v-9.1h-36.6l-2.8-21.4
                            h39.4v-20.4l2.9,0.7v19.7h51.1c9.6,0,14.6-4.1,14.6-12.7C260.4,417.2,256.9,413.4,254.4,411.9z"/>
                        <path d="M163.6,343.5c5,2.6,7,8.7,4.6,13.7c-2.6,5.1-8.6,7.2-13.7,4.6c-2.6-1.2-4.1-3.4-4.6-6c-0.3-2.6-3.6,0-3.6,6.3
                            c0,6.7,10.1,10.8,45.6,10.8v-18.3l2.9,0.5V373h56.9c9.4,0,14.7-0.9,16.4-7h2.9v35.1h-2.9c-1.9-6.5-7.7-6.7-16.4-6.7h-56.9v11
                            l-2.9,0.2v-11.1c-39.6,0-48.5-11.1-48.5-31.9c0-9.4,5.7-16.4,8.6-18.2C155,342.3,160,341.8,163.6,343.5z"/>
                        <path d="M229.9,194.8v54.5c16.8-1.4,25.5-9.9,28.1-21.4c2.1-9.3-1.4-23-9.4-27.2l1.5-2.9c8.9,2.7,22.4,12.8,22.4,35.8
                            c0,22.4-20.7,37.9-40.8,37.9c-24.2,0-41.5-16.4-41.5-40.1C190.3,206.4,203.1,194.8,229.9,194.8z M227,215.7
                            c-21.6,0-33.7,7-33.7,16.4c0,10.1,17.3,17.1,33.7,17.1V215.7z"/>
                        <path d="M229.9,32.2v54.5c16.8-1.4,25.5-9.9,28.1-21.4c2.1-9.3-1.4-23-9.4-27.2l1.5-2.9c8.9,2.7,22.4,12.8,22.4,35.8
                            c0,22.4-20.7,37.9-40.8,37.9c-24.2,0-41.5-16.4-41.5-40.1C190.3,43.8,203.1,32.2,229.9,32.2z M227,53.1c-21.6,0-33.7,7-33.7,16.4
                            c0,10.1,17.3,17.1,33.7,17.1V53.1z"/>
                        <path d="M193.3,283.7c4.6-5.3,12.8-5.8,18-1.2c5.3,4.6,6,12.5,1.4,18c-2.4,2.6-5.3,3.9-8.4,3.9c-1.9,0-0.2,7,10.1,13.4h35.6
                            c9.6,0,16.3-0.9,18-7h2.9v35.5H268c-2.1-6.7-9.1-6.9-18-6.9h-38c-5.8,0-8.4,1.5-12,8.6h-4.5l-3.9-30.2h18
                            c-14.2-9.1-16.8-16.1-18.5-20.2C189.6,294,190.3,287.5,193.3,283.7z"/>
                        <path d="M193.3,121.1c4.6-5.3,12.8-5.8,18-1.2c5.3,4.6,6,12.5,1.4,18c-2.4,2.6-5.3,3.9-8.4,3.9c-1.9,0-0.2,7,10.1,13.4h35.6
                            c9.6,0,16.3-0.9,18-7h2.9v35.5H268c-2.1-6.7-9.1-6.9-18-6.9h-38c-5.8,0-8.4,1.5-12,8.6h-4.5l-3.9-30.2h18
                            c-14.2-9.1-16.8-16.1-18.5-20.2C189.6,131.4,190.3,124.9,193.3,121.1z"/>
                        <path d="M272.5,11.8c0,6.5-5.1,11.7-11.6,11.7c-6.5,0-11.6-5.1-11.6-11.7c0-6.5,5.1-11.8,11.6-11.8C267.4,0,272.5,5.3,272.5,11.8z"
                            />
                    </g>
                </svg>
            </a>
        </div>
        <div class="logo mobile">
            <a class="next-page" data-href="/index.php">
                <svg version="1.1"
                     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
                     x="0px" y="0px" width="128.3px" height="272.5px" viewBox="0 0 128.3 272.5" style="enable-background:new 0 0 128.3 272.5;"
                     xml:space="preserve">
                <defs>
                </defs>
                <g>
                    <path d="M96.1,0v32.6h-2.9C87.2,1.4,40.8,2.9,40.8,2.9h-6v55.2h6c0,0,26.4,0.7,29.5-17.6h2.9V79h-2.9
                        c-3.1-18.3-29.5-17.6-29.5-17.6h-6v35.8c0,19.4,7.4,20.6,14.7,20.6v2.9H0v-2.9c7.4,0,9.9-8.9,9.9-20.6V23.6C9.9,13,7.5,2.9,0,2.9V0
                        H96.1z"/>
                    <path d="M37.2,219.6v27.9c0,19.4,12.9,20.6,20.2,20.6v2.9H1v-2.9c7.2,0,11.3-8.9,11.3-20.6V173c0-10.6-4.8-19.7-12.3-19.7v-2.9
                        h43.3c34.1,0,58.3,6,58.3,34.6c0,28.6-24.2,34.6-58.3,34.6H37.2z M37.2,216.7h6.2c16.8,0,30.2-1.4,30.2-31.7
                        c0-30.5-13.4-31.7-30.2-31.7h-6.2V216.7z"/>
                    <path d="M116.5,272.5c-6.5,0-11.7-5.1-11.7-11.6c0-6.5,5.1-11.6,11.7-11.6c6.5,0,11.8,5.1,11.8,11.6
                        C128.3,267.4,123,272.5,116.5,272.5z"/>
                </g>
                </svg>
            </a>
        </div>
    </div>
    <nav>
        <a class="next-page son_click" data-href="/all.php">
            <div class="barre-menu"></div>
            <div class="barre-menu"></div>
            <div class="barre-menu"></div>
        </a>
    </nav>
</header>
<div id="order-print">
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="687.6px" height="844px" viewBox="0 0 687.6 844" style="enable-background:new 0 0 687.6 844;" xml:space="preserve">
        <path d="M651.7,192H487.9v-48.1C487.9,64.4,423.5,0,344,0h-0.2c-79.6,0-144.9,64.4-144.9,143.9V192H36L0,844h687.6L651.7,192z
         M238.9,143.9C238.9,86.7,286.6,41,343.8,41h0.2c57.2,0,102.9,45.8,102.9,102.9V192h-208V143.9z M42.9,803l31.5-570h124.5v169h40
        V233h208v169h41V233h125.4l31.5,570H42.9z"/>
    </svg>
</div>
<div class="infos-order">
    <div id="info-order-trigger">
        <span class="ferme">close</span>
    </div>
    <div class="info-order-container">
        <div class="info-order-content">
            <p>
                Prints are soon available, you can contact me by email in the meantime.            </p>
        </div>
    </div>
</div>
<div class="nxt-push">
    <span class="nxt-icon">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="11.7px" height="22.2px" viewBox="0 0 11.7 22.2" style="enable-background:new 0 0 11.7 22.2;" xml:space="preserve">
        <defs>
        </defs>
            <path d="M11.7,11.6L1,22.2l-1-0.9l10.2-10.2L0.1,0.9L1,0l10.7,10.6V11.6z"/>
        </svg>
    </span>
</div>
<div class="prv-push">
    <span class="nxt-icon">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="11.6px" height="22.2px" viewBox="0 0 11.6 22.2" style="enable-background:new 0 0 11.6 22.2;" xml:space="preserve">
            <defs>
            </defs>
            <path d="M11.6,0.9L1.5,11.1l10.2,10.2l-0.9,0.9L0,11.6v-0.9L10.7,0L11.6,0.9z"/>
        </svg>
    </span>
</div>            <main>
                <div class="infos">
                    <div id="info-trigger">
                        <span class="ouvre">infos</span>
                        <span class="ferme">close</span>
                    </div>
                    <div class="info-container">
                        <div class="info-content">
                            <p>
                                Although their worn skin discloses a long experience of life, their smiles bring the graces of youth immediately back on their faces.They live in the famous Shangri la city, squeezed between an azure lake and continuous snowy mountains. Here the idleness of large cities has no hold, work is an integral part of everyday life, mutual aid takes precedence over individualism.                            </p>
                        </div>
                    </div>
                </div>
                <div class="breadcrumb">
                  <ul>
                      <li class="before">
                        <a class="next-page" data-href="../index.php">Home</a>
                      </li>
                      <li class="before">
                        —
                      </li>
                        <li class="before">
                          <a class="next-page" data-href="/all.php">ALL</a>
                        </li>
                        <li class="before">
                          —
                        </li>
                        <li class="before">
                            <a class="next-page" data-href="documentary.php">Documentary</a>
                        </li>
                        <li class="before">
                          —
                        </li>
                        <li>
                            03. Shangri La                        </li>
                  </ul>
                </div>
                <div class="loader">
    <section></section>
    <section></section>
    <section></section>
    <section></section>
    <section></section>
</div>                <div id="scrollable">
                    <div id="sectionwrapper">
                        <section class="snap" data-snapcurrent="0">
                            <div class="width-img">
                                <img src="/img/documentary/03-shangrila/01.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="1">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/02.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="2">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/03.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="3">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/04.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="4">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/05.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="5">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/06.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="6">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/07.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        <section class="snap" data-snapcurrent="7">
                            <div class="width-img">
                                <div class="prev"></div>
                                <img src="/img/documentary/03-shangrila/08.jpg" alt="" />
                                <div class="nxt"></div>
                            </div>
                        </section>
                        
                        <section class="snap" data-snapcurrent="8">
                            <div class="prev"></div>
                            <div class="cover-img">
                                <img src="/img/documentary/04-mumbai/cover2.jpg" class="img-cover x3-mouve" alt="" />
                            </div>
                            <div class="cover-txt next-page" data-href="04-mumbai.php">
                                <h2 class="x-mouve">NXT</h2>
                                <h3>
                                    <span>Documentary</span>
                                    <span>Mumbai</span>
                                </h3>
                                <p></p>
                            </div>
                        </section>
                    </div>
                </div>
            </main>
            <div id="subnav-footer">
    <a class="next-page" data-href="/fashion/editorial/index.php" id="1" data-hover="Fashion">Fashion</a>
    <a class="next-page" data-href="/fashion/commissioned/index.php" id="2" data-hover="Commissioned">Commissioned</a>
    <a class="next-page" data-href="/fashion/portrait/index.php" id="3" data-hover="Portrait">Portrait</a>
    <a class="next-page active" data-href="/documentary/index.php" id="4" data-hover="Documentary">Documentary</a>
    <a class="next-page" data-href="/testshoot/index.php" id="5" data-hover="Testshoot">Testshoot</a>
</div>            <div class="about">
    <a class="next-page" data-href="/about.php">
        about
    </a>
<a class="social-icon" href="https://www.instagram.com/florentpetitfrerephotography/" target="_blank">
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="24px" height="24px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve">
    <defs>
    </defs>
    <path class="st0" d="M12,2.2c3.2,0,3.6,0,4.9,0.1c3.3,0.1,4.8,1.7,4.9,4.9c0.1,1.3,0.1,1.6,0.1,4.8c0,3.2,0,3.6-0.1,4.8
        c-0.1,3.2-1.7,4.8-4.9,4.9c-1.3,0.1-1.6,0.1-4.9,0.1c-3.2,0-3.6,0-4.8-0.1c-3.3-0.1-4.8-1.7-4.9-4.9c-0.1-1.3-0.1-1.6-0.1-4.8
        c0-3.2,0-3.6,0.1-4.8c0.1-3.2,1.7-4.8,4.9-4.9C8.4,2.2,8.8,2.2,12,2.2z M12,0C8.7,0,8.3,0,7.1,0.1c-4.4,0.2-6.8,2.6-7,7
        C0,8.3,0,8.7,0,12s0,3.7,0.1,4.9c0.2,4.4,2.6,6.8,7,7C8.3,24,8.7,24,12,24s3.7,0,4.9-0.1c4.4-0.2,6.8-2.6,7-7C24,15.7,24,15.3,24,12
        s0-3.7-0.1-4.9c-0.2-4.4-2.6-6.8-7-7C15.7,0,15.3,0,12,0z M12,5.8c-3.4,0-6.2,2.8-6.2,6.2s2.8,6.2,6.2,6.2s6.2-2.8,6.2-6.2
        C18.2,8.6,15.4,5.8,12,5.8z M12,16c-2.2,0-4-1.8-4-4c0-2.2,1.8-4,4-4s4,1.8,4,4C16,14.2,14.2,16,12,16z M18.4,4.2
        c-0.8,0-1.4,0.6-1.4,1.4S17.6,7,18.4,7c0.8,0,1.4-0.6,1.4-1.4S19.2,4.2,18.4,4.2z"/>
    </svg>
</a> 
<a class="social-icon" href="https://www.facebook.com/florentpetitfrerephotography" target="_blank">
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="12px" height="24px" viewBox="0 0 12 24" style="enable-background:new 0 0 12 24;" xml:space="preserve">
    <defs>
    </defs>
    <path class="st0" d="M3,8H0v4h3v12h5V12h3.6L12,8H8V6.3C8,5.4,8.2,5,9.1,5H12V0H8.2C4.6,0,3,1.6,3,4.6V8z"/>
    </svg>
</a>
</div>

<div class="contact">
    <a class="next-page" data-href="/contact.php">
        contact
    </a>
</div>
<audio id="son_click">
    <source src="/audio/slider.mp3" type="audio/mp3" />
</audio>

<audio id="son_home" loop>
    <source src="/audio/homepage.mp3" type="audio/mp3" />
</audio>

<script> 
var $buoop = {vs:{i:11,f:-2,o:-2,s:8,c:-2},unsecure:true,api:4}; 
function $buo_f(){ 
 var e = document.createElement("script"); 
 e.src = "//browser-update.org/update.min.js"; 
 document.body.appendChild(e);
};
try {document.addEventListener("DOMContentLoaded", $buo_f,false)}
catch(e){window.attachEvent("onload", $buo_f)}
</script>        </div>
        <script src="/js/jquery-3.1.1.min.js"></script>
<script src="/js/slick.min.js"></script>
<script src='/js/ftscroller.min.js'></script>
<script src='/js/tweenmax.min.js'></script>
<script src="/js/script.js"></script>
<script src="/js/jquery.jigowatt.min.js"></script>
<script src="/js/pace.min.js"></script>
    </body>
</html>
